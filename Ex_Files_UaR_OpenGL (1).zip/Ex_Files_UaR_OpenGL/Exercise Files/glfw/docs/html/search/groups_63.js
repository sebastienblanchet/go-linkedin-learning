var searchData=
[
  ['clipboard_20support',['Clipboard support',['../group__clipboard.html',1,'']]],
  ['context_20handling',['Context handling',['../group__context.html',1,'']]]
];
